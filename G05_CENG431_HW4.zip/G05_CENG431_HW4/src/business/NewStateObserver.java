//G05

package business;

public class NewStateObserver implements Observer {

	@Override
	public void update(Process process, String status) {
		if (status.toUpperCase().equals("NEW")) {
			process.setState(State.NEW);
		}
	}

}