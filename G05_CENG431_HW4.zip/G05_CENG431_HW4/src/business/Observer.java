//G05

package business;

public interface Observer {

	public void update(Process process, String status);

}