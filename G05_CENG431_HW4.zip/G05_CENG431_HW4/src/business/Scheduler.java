//G05

package business;

import java.util.ArrayList;

public interface Scheduler {
	public ArrayList<Process> schedule(ArrayList<Process> batchProcesses);
}
