//G05

package business;

import java.util.ArrayList;
import java.util.Random;

public class ProcessBatch {
	private ArrayList<Process> batchProcessesList;
	private ArrayList<Process> scheduledProcessList;

	public ProcessBatch() {
		this.batchProcessesList = new ArrayList<Process>();
		this.scheduledProcessList = new ArrayList<Process>();
	}

	// Add process to list which is not prioritized
	public void addProcess(Process newProcess) {
		this.batchProcessesList.add(newProcess);
	}

	// Strategy selection : Randomly select a scheduling algorithm
	// By default program chooses First Come First Serve Algorithm
	// Schedule the list by selected scheduling algorithm
	public void scheduleList() {
		Random rand = new Random();
		int randomSchedulingAlgorithm = rand.nextInt(3) + 1;
		Scheduler scheduler;
		ArrayList<Process> scheduledList = null;

		switch (randomSchedulingAlgorithm) {
		// First Come First Serve Algorithm
		case 1:
			scheduler = new FirstComeFirstServe();
			scheduledList = scheduler.schedule(this.batchProcessesList);
			setScheduledProcessList(scheduledList);
			System.out.println("First Come First Serve Algorithm Selected.");
			break;
		// Shortest Job First Algorithm
		case 2:
			scheduler = new ShortestJobFirst();
			scheduledList = scheduler.schedule(this.batchProcessesList);
			setScheduledProcessList(scheduledList);
			System.out.println("Shortest Job First Algorithm Selected.");
			break;
		// Priority based Scheduling algorithm
		case 3:
			scheduler = new Priority();
			scheduledList = scheduler.schedule(this.batchProcessesList);
			setScheduledProcessList(scheduledList);
			System.out.println("Priority Base Scheduling Algorithm Selected.");
			break;
		default:
			scheduler = new FirstComeFirstServe();
			scheduledList = scheduler.schedule(this.batchProcessesList);
			setScheduledProcessList(scheduledList);
			System.out.println("First Come First Serve Algorithm Selected.");
			break;

		}
	}

	public void arrangeWaitAndCompletionTime() {
		this.scheduledProcessList.get(0).setWaitingTime(0);
		int firstProcessCompletionTime = this.scheduledProcessList.get(0).getArrivalTime()
				+ this.scheduledProcessList.get(0).getBurstTime();
		this.scheduledProcessList.get(0).setCompletionTime(firstProcessCompletionTime);
		for (int i = 1; i < this.scheduledProcessList.size(); i++) {
			// Calculation for Process's waiting time
			int processWaitTime = this.scheduledProcessList.get(i - 1).getCompletionTime()
					- this.scheduledProcessList.get(i).getArrivalTime();
			this.scheduledProcessList.get(i).setWaitingTime(processWaitTime);
			// Calculation for Process's completion time
			int processCompletionTime = this.scheduledProcessList.get(i).getArrivalTime()
					+ this.scheduledProcessList.get(i).getBurstTime()
					+ this.scheduledProcessList.get(i).getWaitingTime();
			this.scheduledProcessList.get(i).setCompletionTime(processCompletionTime);
			// For detecting starvation check whether process' waiting time
			if (this.scheduledProcessList.get(i).getWaitingTime() >= 50) {
				// Notify that Processes states changed to starved
				this.scheduledProcessList.get(i).notifyObserver("STARVED");
			}
		}
	}

	public ArrayList<Process> getBatchProcessesList() {
		return batchProcessesList;
	}

	public void setBatchProcessesList(ArrayList<Process> batchProcessesList) {
		this.batchProcessesList = batchProcessesList;
	}

	public ArrayList<Process> getScheduledProcessList() {
		return scheduledProcessList;
	}

	public void setScheduledProcessList(ArrayList<Process> scheduledProcessList) {
		this.scheduledProcessList = scheduledProcessList;
	}

}
