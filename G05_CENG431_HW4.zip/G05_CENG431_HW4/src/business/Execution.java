//G05

package business;

import java.util.ArrayList;

import business.Process;

public class Execution {
	private ArrayList<Process> processList;

	public Execution(ArrayList<Process> readyQueue) {
		setProcessList(readyQueue);
	}

	public ArrayList<Process> getProcessList() {
		return processList;
	}

	public void setProcessList(ArrayList<Process> processList) {
		this.processList = processList;
	}

	public void addProcess(Process process) {
		this.processList.add(process);
	}

	// Runs the scheduled processes and changes the state of successfully executed
	// processes to terminated
	public void runExecutor() throws InterruptedException {
		for (Process process : this.processList) {
			if (process.getState() == State.RUNNING) {
				System.out.println("Process " + process.getId() + " running.." + " Arrival Time: "
						+ process.getArrivalTime() + " Burst Time: " + process.getBurstTime() + " CompletionTime: "
						+ process.getCompletionTime() + " Waiting Time: " + process.getWaitingTime() + " Priority: "
						+ process.getPriority());
				// Notify observers that process states changed to terminated
				process.notifyObserver("TERMINATED");
				System.out.println("Process " + process.getId() + " Status: " + process.getState());

			} else {
				System.out.println(
						"Process " + process.getId() + " blocked." + " Waiting Time: " + process.getWaitingTime());
			}
		}
	}

}
