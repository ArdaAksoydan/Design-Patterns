//G05

package business;

public class RunningStateObserver implements Observer {

	@Override
	public void update(Process process, String status) {
		if (status.toUpperCase().equals("RUNNING")) {
			process.setState(State.RUNNING);
		}
	}
}