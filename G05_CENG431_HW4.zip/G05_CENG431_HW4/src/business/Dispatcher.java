//G05

package business;

import java.util.ArrayList;

public class Dispatcher {
	private ArrayList<Process> readyQueue;

	public Dispatcher(ArrayList<Process> scheduledList) {
		this.readyQueue = scheduledList;
	}

	// Checking for process which state before execution
	public void arrangeReadyQueue() {
		for (Process process : this.readyQueue) {
			if (process.getState() == State.STARVED) {
				// System.out.println("Starvation at process " + process.getId());
				// Notify observers that process states changed to blocked
				process.notifyObserver("BLOCKED");

			}
			// Otherwise set state to running for execution
			else {
				// Notify that Processes states changed to running
				process.notifyObserver("RUNNING");
			}
		}
	}

	public ArrayList<Process> getReadyQueue() {
		return readyQueue;
	}

	public void setReadyQueue(ArrayList<Process> readyQueue) {
		this.readyQueue = readyQueue;
	}

}
