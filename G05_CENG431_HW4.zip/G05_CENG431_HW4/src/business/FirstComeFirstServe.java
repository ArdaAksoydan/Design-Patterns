//G05

package business;

import java.util.ArrayList;

public class FirstComeFirstServe implements Scheduler {

	public ArrayList<Process> schedule(ArrayList<Process> processList) {
		for (int i = 0; i < processList.size() - 1; i++) {
			int index = i;
			for (int j = i + 1; j < processList.size(); j++) {
				if (processList.get(j).getArrivalTime() < processList.get(index).getArrivalTime()) {
					index = j;
				}
			}

			Process earlyProcess = processList.get(index);
			processList.set(index, processList.get(i));
			processList.set(i, earlyProcess);
		}

		for (Process element : processList) {
			// Notify observers that process states changed to ready
			element.notifyObserver("READY");
		}
		return processList;
	}
}