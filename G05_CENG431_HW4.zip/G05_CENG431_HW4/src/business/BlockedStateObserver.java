//G05

package business;

public class BlockedStateObserver implements Observer {

	@Override
	public void update(Process process, String status) {
		if (status.toUpperCase().equals("BLOCKED")) {
			process.setState(State.BLOCKED);
		}
	}

}