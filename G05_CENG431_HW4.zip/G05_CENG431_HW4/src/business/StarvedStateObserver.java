//G05

package business;

public class StarvedStateObserver implements Observer {

	@Override
	public void update(Process process, String status) {
		if (status.toUpperCase().equals("STARVED")) {
			process.setState(State.STARVED);
		}
	}

}