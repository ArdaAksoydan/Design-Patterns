//G05

package business;

import java.util.ArrayList;
import java.util.List;

public class Priority implements Scheduler {

	public ArrayList<Process> schedule(ArrayList<Process> processList) {

		ArrayList<Process> scheduledProcessList = new ArrayList<Process>();
		int minArrivalTime;
		int nextAvailableTime;
		ArrayList<Process> arrivedWhenBusy;

		sortByArrivalTime(processList);
		scheduledProcessList.add(processList.get(0));
		minArrivalTime = processList.get(0).getArrivalTime();
		nextAvailableTime = processList.get(0).getArrivalTime() + processList.get(0).getBurstTime();
		processList.remove(0);

		while (!processList.isEmpty()) {

			arrivedWhenBusy = new ArrayList<Process>();

			for (Process process : processList) {
				if (minArrivalTime <= process.getArrivalTime() && process.getArrivalTime() <= nextAvailableTime) {
					arrivedWhenBusy.add(process);
				}
			}
			if (!arrivedWhenBusy.isEmpty()) {
				sortByPriority(arrivedWhenBusy);
				for (Process process : processList) {
					if (process.equals(arrivedWhenBusy.get(0))) {
						scheduledProcessList.add(process);
						nextAvailableTime = nextAvailableTime + arrivedWhenBusy.get(0).getBurstTime();
						processList.remove(process);
						break;
					}
				}
			} else {
				sortByArrivalTime(processList);
				scheduledProcessList.add(processList.get(0));
				nextAvailableTime = nextAvailableTime + processList.get(0).getBurstTime();
				processList.remove(0);
			}

		}

		for (Process element : scheduledProcessList) {
			// Notify observers that process states changed to ready
			element.notifyObserver("READY");
		}
		return scheduledProcessList;
	}

	public void sortByArrivalTime(List<Process> processList) {
		for (int i = 0; i < processList.size() - 1; i++) {
			int index = i;
			for (int j = i + 1; j < processList.size(); j++) {
				if (processList.get(j).getArrivalTime() < processList.get(index).getArrivalTime()) {
					index = j;
				}
			}

			Process earlyProcess = processList.get(index);
			processList.set(index, processList.get(i));
			processList.set(i, earlyProcess);
		}
	}

	public void sortByPriority(List<Process> processList) {
		for (int i = 0; i < processList.size() - 1; i++) {
			int index = i;
			for (int j = i + 1; j < processList.size(); j++) {
				if (processList.get(j).getPriority() < processList.get(index).getPriority()) {
					index = j;
				}
			}

			Process moreImportantProcess = processList.get(index);
			processList.set(index, processList.get(i));
			processList.set(i, moreImportantProcess);
		}
	}
}