//G05

package business;

public enum State {
	NEW, READY, RUNNING, BLOCKED, STARVED, TERMINATED;
}