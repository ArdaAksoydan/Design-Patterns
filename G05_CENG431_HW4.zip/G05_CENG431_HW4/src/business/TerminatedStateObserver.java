//G05

package business;

public class TerminatedStateObserver implements Observer {

	@Override
	public void update(Process process, String status) {
		if (status.toUpperCase().equals("TERMINATED")) {
			process.setState(State.TERMINATED);
		}
	}

}