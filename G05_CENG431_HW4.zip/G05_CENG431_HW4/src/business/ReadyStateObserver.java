//G05

package business;

public class ReadyStateObserver implements Observer {

	@Override
	public void update(Process process, String status) {
		if (status.toUpperCase().equals("READY")) {
			process.setState(State.READY);
		}
	}

}