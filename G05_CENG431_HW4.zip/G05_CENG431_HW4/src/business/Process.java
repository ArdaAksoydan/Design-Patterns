//G05

package business;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Process {

	private int id;
	private int arrivalTime;
	private int burstTime;
	private int completionTime;
	private int waitingTime;
	private int priority;
	private State state;
	private static Random rand = new Random();
	private List<Observer> observers;

	public Process(int id) {
		this.id = id;
		this.arrivalTime = rand.nextInt(20) + 1;
		this.burstTime = rand.nextInt(20) + 1;
		this.priority = rand.nextInt(10) + 1;
		this.observers = new ArrayList<Observer>();
	}

	public void register(Observer newObserver) {
		observers.add(newObserver);
	}

	public void unregister(Observer oldObserver) {
		int observerIndex = observers.indexOf(oldObserver);
		if (observerIndex < 0) {
			System.out.println("Observer could not found.");
		}
		observers.remove(observerIndex);
	}

	public void notifyObserver(String status) {
		for (Observer observer : observers) {
			observer.update(this, status);
		}
	}

	public void setWaitingTime(int waitingTime) {
		if (waitingTime < 0) {
			this.waitingTime = 0;
		} else {
			this.waitingTime = waitingTime;
		}
	}

	public void setCompletionTime(int completionTime) {
		this.completionTime = completionTime;
	}

	public int getId() {
		return id;
	}

	public int getArrivalTime() {
		return arrivalTime;
	}

	public int getBurstTime() {
		return burstTime;
	}

	public int getCompletionTime() {
		return completionTime;
	}

	public int getWaitingTime() {
		return waitingTime;
	}

	public int getPriority() {
		return priority;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Process [id=" + id + ", arrivalTime=" + arrivalTime + ", burstTime=" + burstTime + ", completionTime="
				+ completionTime + ", waitingTime=" + waitingTime + ", priority=" + priority + ", state=" + state
				+ ", observers=" + observers + "]";
	}

}