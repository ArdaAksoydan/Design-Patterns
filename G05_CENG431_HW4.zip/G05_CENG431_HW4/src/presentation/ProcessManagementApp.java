//G05

package presentation;

import java.util.ArrayList;

import business.*;
import business.Process;

public class ProcessManagementApp {
	public static void main(String[] args) throws InterruptedException {

		Observer newState = new NewStateObserver();
		Observer readyState = new ReadyStateObserver();
		Observer runningState = new RunningStateObserver();
		Observer starvedState = new StarvedStateObserver();
		Observer blockedState = new BlockedStateObserver();
		Observer terminatedState = new TerminatedStateObserver();

		ProcessBatch processBatch = new ProcessBatch();
		for (int i = 1; i < 6; i++) {
			Process process = new Process(i);
			process.register(newState);
			process.register(readyState);
			process.register(runningState);
			process.register(starvedState);
			process.register(blockedState);
			process.register(terminatedState);
			processBatch.addProcess(process);
			process.notifyObserver("NEW");

		}

		processBatch.scheduleList();
		processBatch.arrangeWaitAndCompletionTime();

		Dispatcher dispatcher = new Dispatcher(processBatch.getScheduledProcessList());
		dispatcher.arrangeReadyQueue();
		ArrayList<Process> readyQueue = dispatcher.getReadyQueue();

		Execution cpu = new Execution(readyQueue);
		cpu.runExecutor();
		System.out.println("Program Terminated.");
	}

}