//G05

package presentation;

import business.*;

public class ComputerComparisonApp {

	public static void main(String[] args) {

		Computer computer = null;
		ComputerFactory firstFactory = new RegularComputerFactory();
		ComputerFactory secondFactory = new GamingComputerFactory();

		computer = firstFactory.createComputer();
		System.out.println(computer.toString());

		computer = secondFactory.createComputer();
		System.out.println(computer.toString());

	}
}