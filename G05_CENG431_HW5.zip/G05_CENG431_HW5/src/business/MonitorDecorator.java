//G05

package business;

public class MonitorDecorator implements Monitor {
	protected Monitor monitor;

	public MonitorDecorator(Monitor monitor) {
		this.monitor = monitor;
	}

	@Override
	public void operation() {
		System.out.println("Monitor Decorated");
	}

	@Override
	public void increasePrice(int price) {
		this.monitor.increasePrice(price);
		;

	}

	@Override
	public void increaseSpeed(int speedMultiplier) {
		this.monitor.increaseSpeed(speedMultiplier);

	}

	@Override
	public int getPrice() {
		return this.monitor.getPrice();
	}

	@Override
	public int getSpeed() {
		return this.monitor.getSpeed();
	}

}
