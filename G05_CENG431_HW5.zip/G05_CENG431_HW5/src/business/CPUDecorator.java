//G05

package business;

public class CPUDecorator implements CPU {
	protected CPU cpu;

	public CPUDecorator(CPU cpu) {
		this.cpu = cpu;
	}

	@Override
	public void operation() {
		System.out.println("CPU Decorated");
	}

	@Override
	public void increasePrice(int price) {
		this.cpu.increasePrice(price);

	}

	@Override
	public void increaseSpeed(int speedMultiplier) {
		this.cpu.increaseSpeed(speedMultiplier);

	}

	@Override
	public int getPrice() {
		return this.cpu.getPrice();
	}

	@Override
	public int getSpeed() {
		return this.cpu.getSpeed();
	}

}
