//G05

package business;

public class MouseDecorator implements Mouse {
	protected Mouse mouse;

	public MouseDecorator(Mouse mouse) {
		this.mouse = mouse;
	}

	@Override
	public void operation() {
		System.out.println("Mouse Decorated");
	}

	@Override
	public void increasePrice(int price) {
		this.mouse.increasePrice(price);
	}

	@Override
	public void increaseSpeed(int speedMultiplier) {
		this.mouse.increaseSpeed(speedMultiplier);

	}

	@Override
	public int getPrice() {
		return this.mouse.getPrice();
	}

	@Override
	public int getSpeed() {
		return this.mouse.getSpeed();
	}

}
