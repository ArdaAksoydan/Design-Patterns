//G05

package business;

public class SilverCabledMouse extends MouseDecorator {

	public SilverCabledMouse(Mouse mouse) {
		super(mouse);
	}

	public void operation() {
		increasePrice();
		increaseSpeed();
	}

	public void increasePrice() {
		super.increasePrice(350);
	}

	public void increaseSpeed() {
		super.increaseSpeed(4);
	}

	public String toString() {
		return "Silver" + mouse.toString();
	}
}