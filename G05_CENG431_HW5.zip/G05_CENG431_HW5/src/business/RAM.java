//G05

package business;

public interface RAM {
	public void operation();

	public int getPrice();

	public int getSpeed();

	public void increasePrice(int price);

	public void increaseSpeed(int speedMultiplier);
}