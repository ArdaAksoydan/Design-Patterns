//G05

package business;

public class BasicMonitor implements Monitor {
	private float inch;
	private int price, speed;

	public BasicMonitor(float inch, int price) {
		this.inch = inch;
		this.price = price;
		this.speed = 10;
	}

	public void operation() {
		System.out.println("Basic Keyboard");
	}

	public void increasePrice(int price) {
		this.price += price;
	}

	public void increaseSpeed(int speedMultiplier) {
		this.speed *= speedMultiplier;
	}

	public int getPrice() {
		return price;
	}

	public int getSpeed() {
		return speed;
	}

	public float getInch() {
		return inch;
	}

	@Override
	public String toString() {
		return "Monitor [Inch=" + inch + ", price=" + price + ", speed=" + speed + "]";
	}

}
