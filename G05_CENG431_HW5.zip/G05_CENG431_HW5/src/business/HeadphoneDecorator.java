//G05

package business;

public class HeadphoneDecorator implements Headphone {

	protected Headphone headphone;

	public HeadphoneDecorator(Headphone headphone) {
		this.headphone = headphone;
	}

	@Override
	public void operation() {
		System.out.println("Headphone Decorated");

	}

	@Override
	public int getPrice() {
		return this.headphone.getPrice();
	}

	@Override
	public int getSpeed() {
		return this.headphone.getSpeed();
	}

	@Override
	public void increasePrice(int price) {
		this.headphone.increasePrice(price);

	}

	@Override
	public void increaseSpeed(int speedMultiplier) {
		this.headphone.increaseSpeed(speedMultiplier);

	}

}
