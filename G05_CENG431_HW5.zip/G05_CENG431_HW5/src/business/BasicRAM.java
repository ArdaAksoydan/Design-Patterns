//G05

package business;

public class BasicRAM implements RAM {
	private int capacity;
	private int price;
	private int speed;

	public BasicRAM(int capacity, int price) {
		this.capacity = capacity;
		this.price = price;
		this.speed = 10;
	}

	@Override
	public void operation() {
		System.out.println("Basic RAM");
	}

	@Override
	public void increasePrice(int price) {
		this.price += price;
	}

	@Override
	public void increaseSpeed(int speedMultiplier) {
		this.speed *= speedMultiplier;
	}

	public int getCapacity() {
		return capacity;
	}

	public int getPrice() {
		return price;
	}

	public int getSpeed() {
		return speed;
	}

	@Override
	public String toString() {
		return "RAM [capacity=" + capacity + ", price=" + price + ", speed=" + speed + "]";
	}
}
