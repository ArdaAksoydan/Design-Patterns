//G05

package business;

public class SilverCabledMonitor extends MonitorDecorator {

	public SilverCabledMonitor(Monitor monitor) {
		super(monitor);
	}

	public void operation() {
		increasePrice();
		increaseSpeed();
	}

	public void increasePrice() {
		super.increasePrice(350);
	}

	public void increaseSpeed() {
		super.increaseSpeed(4);
	}

	public String toString() {
		return "Silver" + monitor.toString();
	}
}