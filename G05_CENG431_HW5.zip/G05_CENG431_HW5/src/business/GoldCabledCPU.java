//G05

package business;

public class GoldCabledCPU extends CPUDecorator {
	public GoldCabledCPU(CPU cpu) {
		super(cpu);
	}

	public void operation() {
		increasePrice();
		increaseSpeed();
	}

	public void increasePrice() {
		super.increasePrice(500);
	}

	public void increaseSpeed() {
		super.increaseSpeed(6);
	}

	public String toString() {
		return "Gold" + cpu.toString();
	}

}