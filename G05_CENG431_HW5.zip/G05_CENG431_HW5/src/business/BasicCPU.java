//G05

package business;

public class BasicCPU implements CPU {
	private String version;
	private String frequency;
	private int price;
	private int speed;

	public BasicCPU(String version, String frequency, int price) {
		this.version = version;
		this.frequency = frequency;
		this.price = price;
		this.speed = 10;
	}

	public void operation() {
		System.out.println("Basic CPU");
	}

	public void increasePrice(int price) {
		this.price += price;
	}

	public void increaseSpeed(int speedMultiplier) {
		this.speed *= speedMultiplier;
	}

	public String getVersion() {
		return version;
	}

	public String getFrequency() {
		return frequency;
	}


	public int getPrice() {
		return price;
	}

	public int getSpeed() {
		return speed;
	}

	@Override
	public String toString() {
		return "CPU [version=" + version + ", frequency=" + frequency + ", price=" + price + ", speed=" + speed + "]";
	}

}