//G05

package business;

public class Computer {
	private String name;
	private int price;
	private int speed;
	private RAM ram;
	private Headphone headphone;
	private Monitor monitor;
	private CPU cpu;
	private Keyboard keyboard;
	private Mouse mouse;

	public Computer(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice() {
		this.price = ram.getPrice() + headphone.getPrice() + monitor.getPrice() + mouse.getPrice() + cpu.getPrice()
				+ keyboard.getPrice();
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed() {
		this.speed = ram.getSpeed() + headphone.getSpeed() + monitor.getSpeed() + mouse.getSpeed() + cpu.getSpeed()
				+ keyboard.getSpeed();
	}

	public RAM getRam() {
		return ram;
	}

	public void setRam(RAM ram) {
		this.ram = ram;
	}

	public Headphone getHeadphone() {
		return headphone;
	}

	public void setHeadphone(Headphone headphone) {
		this.headphone = headphone;
	}

	public Monitor getMonitor() {
		return monitor;
	}

	public void setMonitor(Monitor monitor) {
		this.monitor = monitor;
	}

	public CPU getCpu() {
		return cpu;
	}

	public void setCpu(CPU cpu) {
		this.cpu = cpu;
	}

	public Keyboard getKeyboard() {
		return keyboard;
	}

	public void setKeyboard(Keyboard keyboard) {
		this.keyboard = keyboard;
	}

	public Mouse getMouse() {
		return mouse;
	}

	public void setMouse(Mouse mouse) {
		this.mouse = mouse;
	}

	public String toString() {
		return "Computer Type = " + this.name + " Total Price = " + this.price + " Total Speed = " + this.speed + "\n"
				+ this.ram.toString() + "\n" + this.cpu.toString() + "\n" + this.monitor.toString() + "\n"
				+ this.mouse.toString() + "\n" + this.keyboard.toString() + "\n" + this.headphone.toString() + "\n";
	}

}
