//G05

package business;

public class BasicHeadphone implements Headphone {
	private boolean isWireless;
	private boolean hasMicrophone;
	private int price;
	private int speed;

	public BasicHeadphone(boolean isWireless, boolean hasMicrophone, int price) {
		this.isWireless = isWireless;
		this.hasMicrophone = hasMicrophone;
		this.price = price;
		this.speed = 10;
	}

	@Override
	public void operation() {
		System.out.println("Basic Headphone");
	}

	@Override
	public void increasePrice(int price) {
		this.price += price;
	}

	@Override
	public void increaseSpeed(int speedMultiplier) {
		this.speed *= speedMultiplier;
	}

	public boolean isWireless() {
		return isWireless;
	}

	public boolean isHasMicrophone() {
		return hasMicrophone;
	}

	public int getPrice() {
		return price;
	}

	public int getSpeed() {
		return speed;
	}

	@Override
	public String toString() {
		return "Headphone [isWireless=" + isWireless + ", hasMicrophone=" + hasMicrophone + ", price=" + price
				+ ", speed=" + speed + "]";
	}

}
