//G05

package business;

public class KeyboardDecorator implements Keyboard {
	protected Keyboard keyboard;

	public KeyboardDecorator(Keyboard keyboard) {
		this.keyboard = keyboard;
	}

	@Override
	public void operation() {
		System.out.println("Keyboard Decorated");
	}

	@Override
	public void increasePrice(int price) {
		this.keyboard.increasePrice(price);
	}

	@Override
	public void increaseSpeed(int speedMultiplier) {
		this.keyboard.increaseSpeed(speedMultiplier);

	}

	@Override
	public int getPrice() {
		return this.keyboard.getPrice();
	}

	@Override
	public int getSpeed() {
		return this.keyboard.getSpeed();
	}

}
