//G05

package business;

public class GoldCabledHeadphone extends HeadphoneDecorator {

	public GoldCabledHeadphone(Headphone headphone) {
		super(headphone);
	}

	public void operation() {
		increasePrice();
		increaseSpeed();
	}

	public void increasePrice() {
		super.increasePrice(500);
	}

	public void increaseSpeed() {
		super.increaseSpeed(6);
	}

	public String toString() {
		return "Gold" + headphone.toString();
	}

}
