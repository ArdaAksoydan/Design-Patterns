//G05

package business;

import java.util.Random;

public class GamingComputerFactory implements ComputerFactory {

	@Override
	public Computer createComputer() {
		Computer computer = new Computer("Gaming Computer");
		computer.setKeyboard(createKeyboard());
		computer.setMouse(createMouse());
		computer.setMonitor(createMonitor());
		computer.setHeadphone(createHeadphone());
		computer.setCpu(createCPU());
		computer.setRam(createRAM());
		computer.setPrice();
		computer.setSpeed();
		return computer;
	}

	@Override
	public Keyboard createKeyboard() {
		Keyboard baseKeyboard = null;
		int number = randomNumber(0, 3);
		if (number == 0) {
			baseKeyboard = new BasicKeyboard(randomNumber(84, 108), true, randomNumber(500, 1500));
		} else if (number == 1) {
			baseKeyboard = new SilverCabledKeyboard(
					new BasicKeyboard(randomNumber(84, 108), true, randomNumber(500, 1500)));
			baseKeyboard.operation();
		} else {
			baseKeyboard = new GoldCabledKeyboard(
					new BasicKeyboard(randomNumber(84, 108), true, randomNumber(500, 1500)));
			baseKeyboard.operation();
		}
		return baseKeyboard;
	}

	@Override
	public Mouse createMouse() {
		Mouse baseMouse = null;
		int number = randomNumber(0, 3);
		if (number == 0) {
			baseMouse = new BasicMouse(false, randomNumber(300, 850));
		} else if (number == 1) {
			baseMouse = new SilverCabledMouse(new BasicMouse(false, randomNumber(300, 850)));
			baseMouse.operation();
		} else {
			baseMouse = new GoldCabledMouse(new BasicMouse(false, randomNumber(300, 850)));
			baseMouse.operation();
		}
		return baseMouse;
	}

	@Override
	public Monitor createMonitor() {
		Monitor baseMonitor = null;
		int[] inchList = { 18, 21, 25, 27 };
		int number = randomNumber(0, 3);
		if (number == 0) {
			baseMonitor = new BasicMonitor(randomSwitcher(inchList), randomNumber(2500, 3500));
		} else if (number == 1) {
			baseMonitor = new SilverCabledMonitor(new BasicMonitor(randomSwitcher(inchList), randomNumber(2500, 3500)));
			baseMonitor.operation();
		} else {
			baseMonitor = new GoldCabledMonitor(new BasicMonitor(randomSwitcher(inchList), randomNumber(2500, 3500)));
			baseMonitor.operation();
		}
		return baseMonitor;

	}

	@Override
	public Headphone createHeadphone() {
		Headphone baseHeadphone = null;
		int number = randomNumber(0, 3);
		if (number == 0) {
			baseHeadphone = new BasicHeadphone(true, true, randomNumber(600, 1900));
		} else if (number == 1) {
			baseHeadphone = new SilverCabledHeadphone(new BasicHeadphone(true, true, randomNumber(600, 1900)));
			baseHeadphone.operation();
		} else {
			baseHeadphone = new GoldCabledHeadphone(new BasicHeadphone(true, true, randomNumber(600, 1900)));
			baseHeadphone.operation();
		}
		return baseHeadphone;
	}

	@Override
	public CPU createCPU() {
		CPU baseCPU = null;
		int[] versionList = { 5, 7 };
		int number = randomNumber(0, 3);
		if (number == 0) {
			baseCPU = new BasicCPU("i" + randomSwitcher(versionList), "5.4 GHz", randomNumber(14000, 24000));
		} else if (number == 1) {
			baseCPU = new SilverCabledCPU(
					new BasicCPU("i" + randomSwitcher(versionList), "5.4 GHz", randomNumber(14000, 24000)));
			baseCPU.operation();
		} else {
			baseCPU = new GoldCabledCPU(
					new BasicCPU("i" + randomSwitcher(versionList), "5.4 GHz", randomNumber(14000, 24000)));
			baseCPU.operation();
		}
		return baseCPU;
	}

	@Override
	public RAM createRAM() {
		RAM baseRAM = null;
		int[] memoryList = { 128, 256 };
		int number = randomNumber(0, 3);
		if (number == 0) {
			baseRAM = new BasicRAM(randomSwitcher(memoryList), randomNumber(7000, 19000));
		} else if (number == 1) {
			baseRAM = new SilverCabledRAM(new BasicRAM(randomSwitcher(memoryList), randomNumber(7000, 19000)));
			baseRAM.operation();
		} else {
			baseRAM = new GoldCabledRAM(new BasicRAM(randomSwitcher(memoryList), randomNumber(7000, 19000)));
			baseRAM.operation();
		}
		return baseRAM;
	}

	public int randomNumber(int min, int max) {
		Random rand = new Random();

		return rand.nextInt(max - min) + min;

	}

	public int randomSwitcher(int[] list) {
		Random rand = new Random();

		int n = rand.nextInt(list.length - 1) + 0;
		return list[n];

	}

}