//G05

package business;

public class RAMDecorator implements RAM {

	protected RAM ram;

	public RAMDecorator(RAM ram) {
		this.ram = ram;
	}

	@Override
	public void operation() {
		System.out.println("RAM Decorated");
	}

	@Override
	public int getPrice() {
		return this.ram.getPrice();
	}

	@Override
	public int getSpeed() {
		return this.ram.getSpeed();
	}

	@Override
	public void increasePrice(int price) {
		this.ram.increasePrice(price);

	}

	@Override
	public void increaseSpeed(int speedMultiplier) {
		this.ram.increaseSpeed(speedMultiplier);

	}

}
