//G05

package business;

public class BasicMouse implements Mouse {

	private Boolean isWireless;
	private int price;
	private int speed;

	public BasicMouse(Boolean isWireless, int price) {

		this.isWireless = isWireless;
		this.price = price;
		this.speed = 10;

	}

	public void operation() {
		System.out.println("Basic Mouse");
	}

	public void increasePrice(int price) {
		this.price += price;
	}

	public void increaseSpeed(int speedMultiplier) {
		this.speed *= speedMultiplier;
	}

	public Boolean getIsWireless() {
		return isWireless;
	}

	public int getPrice() {
		return price;
	}

	public int getSpeed() {
		return speed;
	}

	@Override
	public String toString() {
		return "Mouse [isWireless=" + isWireless + ", price=" + price + ", speed=" + speed + "]";
	}

}
