//G05

package business;

public class SilverCabledKeyboard extends KeyboardDecorator {

	public SilverCabledKeyboard(Keyboard keyboard) {
		super(keyboard);
	}

	public void operation() {
		increasePrice();
		increaseSpeed();
	}

	public void increasePrice() {
		super.increasePrice(350);
	}

	public void increaseSpeed() {
		super.increaseSpeed(4);
	}

	public String toString() {
		return "Silver" + keyboard.toString();
	}
}