//G05

package business;

public interface ComputerFactory {
	public Computer createComputer();

	public Keyboard createKeyboard();

	public Mouse createMouse();

	public Monitor createMonitor();

	public Headphone createHeadphone();

	public CPU createCPU();

	public RAM createRAM();
}