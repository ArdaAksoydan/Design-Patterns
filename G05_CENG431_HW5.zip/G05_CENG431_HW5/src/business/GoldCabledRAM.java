//G05

package business;

public class GoldCabledRAM extends RAMDecorator {

	public GoldCabledRAM(RAM ram) {
		super(ram);
	}

	public void operation() {
		increasePrice();
		increaseSpeed();
	}

	public void increasePrice() {
		super.increasePrice(500);
	}

	public void increaseSpeed() {
		super.increaseSpeed(6);
	}

	public String toString() {
		return "Gold" + ram.toString();
	}

}
