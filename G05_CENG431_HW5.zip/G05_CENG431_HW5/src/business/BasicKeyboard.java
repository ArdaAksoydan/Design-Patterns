//G05

package business;

public class BasicKeyboard implements Keyboard {
	private int numberOfKeys, price, speed;
	private Boolean hasBackLight;

	public BasicKeyboard(int numberOfKeys, Boolean hasBackLight, int price) {
		this.numberOfKeys = numberOfKeys;
		this.hasBackLight = hasBackLight;
		this.price = price;
		this.speed = 10;
	}

	public void operation() {
		System.out.println("Basic Keyboard");
	}

	public void increasePrice(int price) {
		this.price += price;
	}

	public void increaseSpeed(int speedMultiplier) {
		this.speed *= speedMultiplier;
	}

	public int getPrice() {
		return price;
	}

	public int getSpeed() {
		return speed;
	}

	public int getNumberOfKeys() {
		return numberOfKeys;
	}

	public Boolean getHasBackLight() {
		return hasBackLight;
	}

	@Override
	public String toString() {
		return "Keyboard [hasBackLight=" + hasBackLight + ", Number of Keys=" + numberOfKeys + ", price=" + price
				+ ", speed=" + speed + "]";
	}

}
