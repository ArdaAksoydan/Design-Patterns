//G05

package business;

public class SilverCabledHeadphone extends HeadphoneDecorator {

	public SilverCabledHeadphone(Headphone headphone) {
		super(headphone);
	}

	public void operation() {
		increasePrice();
		increaseSpeed();
	}

	public void increasePrice() {
		super.increasePrice(350);
	}

	public void increaseSpeed() {
		super.increaseSpeed(4);
	}

	public String toString() {
		return "Silver" + headphone.toString();
	}

}
