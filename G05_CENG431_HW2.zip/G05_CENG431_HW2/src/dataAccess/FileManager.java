//G05

package dataAccess;

import business.*;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class FileManager {
	
	// ***** Operations for customers.jason *****
	
	// --- to write customers to customers.json file ---
    public void writeCustomersFile(ArrayList<Customer> customerList) {
	
        JSONObject object = new JSONObject();
        
		for (int i=0; i<customerList.size(); i++) { 
			
			JSONArray array = new JSONArray();
			
			// customer id numbers are key in .json file
		 	int id = customerList.get(i).getId();
		 	System.out.println(id);
		 	
		 	// other customer informations are in list as a value in .json file
		 	String name = customerList.get(i).getName();
		 	String address = customerList.get(i).getAddress();
		 	double savings = customerList.get(i).getSavings();
		 	String phone = customerList.get(i).getPhone();
		 	String email = customerList.get(i).getEmail();
		 	String password = customerList.get(i).getPassword();
		 	
		 	
		 	ArrayList<String> tempList = new ArrayList<String>(); 
		 	
		 	
		 	tempList.add(name);
		 	tempList.add(address);
		 	tempList.add(String.valueOf(savings));
		 	tempList.add(phone);
		 	tempList.add(email);
		 	tempList.add(password);

		 	
		 	array.addAll(tempList);
		 	
		 	object.put(id, array);
		 	 	
		}	

        try {
            FileWriter file = new FileWriter("customers.json");
            file.write(object.toString());
            file.flush();
            file.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    // --- to get customer information with customer id from customers.json file ---
    public ArrayList readCustomerFromFile() {
        
    	ArrayList<ArrayList<String>> customerInfoList = new ArrayList<ArrayList<String>>() ;
    	
    	JSONParser parser = new JSONParser();
    	File file = new File("customers.json");
    	if(file.exists()) {
    		try {

                Object obj = parser.parse(new FileReader("customers.json"));
                
                JSONObject jsonObject = (JSONObject)obj;
                
            	   for(int i=1;i<= jsonObject.size();i++) {
            		   ArrayList<String> customerInformation = (ArrayList<String>) jsonObject.get(String.valueOf(i));
            		   customerInformation.add(0, Integer.toString(i));
            		   customerInfoList.add(customerInformation);
            	   }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            return customerInfoList;
    	}
    	else {
    		return null;
    	}
        
    }
    
   
	// ***** Operations for orders.jason *****
	
	// --- to write orders to orders.json file ---
    public void writeOrdersFile(ArrayList<Order> orderList) {
	
        JSONObject object = new JSONObject();
        
		for (int i=0; i<orderList.size(); i++) { 
			
			JSONArray array = new JSONArray();
			
			// orderId numbers are key in json file
		 	int id = orderList.get(i).getId();
		 	System.out.println(id);
		 	
		 	// other order informations are in list as a value in json file
		 	double trackingNumber = orderList.get(i).getId();
		 	int customerId = orderList.get(i).getCustomerID();
		 	String customerName = orderList.get(i).getCustomerName();
		 	double weight = orderList.get(i).getWeight();
		 	String shippingAddress = orderList.get(i).getShippingAddress();
		 	Date dateShipped = orderList.get(i).getDateShipped();
		 	Date dateDelivered = orderList.get(i).getDateDelivered();
		 	double productPrice = orderList.get(i).getProductPrice();
		 	double cargoPrice = orderList.get(i).getCargoPrice();
		 	double totalPrice = orderList.get(i).getTotalPrice();
		 	
		 	ArrayList<String> tempList = new ArrayList<String>(); 
		 	

		 	tempList.add(String.valueOf(trackingNumber));
		 	tempList.add(String.valueOf(customerId));
		 	tempList.add(customerName);
		 	tempList.add(String.valueOf(weight));
		 	tempList.add(shippingAddress);
		 	tempList.add(String.valueOf(dateShipped));
		 	tempList.add(String.valueOf(dateDelivered));
		 	tempList.add(String.valueOf(productPrice));
		 	tempList.add(String.valueOf(cargoPrice));
		 	tempList.add(String.valueOf(totalPrice));
		 	
		 	
		 	array.addAll(tempList);
		 	
		 	object.put(id, array);
		 	 	
		}	

        try {
            FileWriter file = new FileWriter("orders.json");
            file.write(object.toString());
            file.flush();
            file.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // --- to get order information with orderId from orders.json file ---
    public ArrayList readOrdersFile() {
        
    	ArrayList<ArrayList<String>> orderInfoList = new ArrayList<ArrayList<String>>();
    	
    	JSONParser parser = new JSONParser();
    	File file = new File("orders.json");
    	if(file.exists()) {
    		try {

                Object obj = parser.parse(new FileReader("orders.json"));
                JSONObject jsonObject = (JSONObject)obj;
                
                for(int i=1;i<= jsonObject.size();i++) {
         		   ArrayList<String> orderInformation = (ArrayList<String>) jsonObject.get(String.valueOf(i));
         		   orderInformation.add(0, Integer.toString(i));
         		   orderInfoList.add(orderInformation);
         	   }
            } catch (Exception e) {
                e.printStackTrace();
            }
    		
            return orderInfoList;
    	}
    	else {
    		return null;
    	}
    }
    
}