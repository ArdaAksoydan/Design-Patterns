//G05

package presentation;

import business.*;
import dataAccess.*;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Scanner;

public class ShoppingMenu {
	private Shopping shopping;
	
	public ShoppingMenu() {
		this.shopping = new Shopping();
	}
	
	public static boolean isInteger(String s, int radix) {
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}
	
	public void loadFiles() {
		shopping.getStore().getCustomersFromFile();
		shopping.getStore().getOrderFromFile();
	}
	public void exit() {
		shopping.getStore().writeToFile();
		System.out.println("Exit status code 0");
		System.exit(0);
	}
	
	public boolean start() throws ParseException{
		System.out.println("Online Shopping System:");
		System.out.println("1-Login");
		System.out.println("2-Register");
		System.out.println("3-Exit");
		//Taking operation input
		Scanner operation= new Scanner(System.in);
		String input = operation.nextLine();
		
		if(isInteger(input, 10)) {
			int inputInt = Integer.parseInt(input);
			switch (inputInt) {
				case 1:
					
					//Login
					System.out.println("Email:");
					String email = operation.nextLine();
					System.out.println("Password:");
					String password = operation.nextLine();
					
					//Logged in condition
					if(shopping.getStore().checkCustomer(email, password) != null) {
						System.out.println("LOGIN SUCCESSFULL");
						System.out.println("1-Save Order");
						System.out.println("2-Submit Order");
						System.out.println("3-Cancel Order");
						String loginOperation = operation.nextLine();
						if(isInteger(loginOperation, 10)) {
							int loginOperationInt = Integer.parseInt(loginOperation);
							switch (loginOperationInt) {
							case 1:
								//Save Order
								System.out.println("Shipping Address:");
								String shippingAddress = operation.nextLine();
								System.out.println("Order weight:");
								String weight = operation.nextLine();
								Order order = shopping.saveOrder(shopping.getStore().checkCustomer(email, password), shippingAddress, Double.parseDouble(weight));
								System.out.println("Order saved successfully. Order id: " + order.getId());
								break;
							case 2:
								//Submit Order
								System.out.println("Order id to submit");
								String orderId = operation.nextLine();
								if(isInteger(orderId, 10) && shopping.getStore().checkOrder(Integer.parseInt(orderId)) != null) {
									shopping.submitOrder(shopping.getStore().checkOrder(Integer.parseInt(orderId)));
									//Charge Customer
									System.out.println("Order Submitted.");
									System.out.println("1-Proceed to pay");
									System.out.println("2-Cancel Order");
									String submitOperation = operation.nextLine();
									switch (Integer.parseInt(submitOperation)) {
									case 1:
										//Charge Customer
										if(shopping.chargeCustomer(shopping.getStore().checkCustomer(email, password), shopping.getStore().checkOrder(Integer.parseInt(orderId)))) {
											//Shipped
											if(shopping.shipOrder(shopping.getStore().checkCustomer(email, password), shopping.getStore().checkOrder(Integer.parseInt(orderId)))) {
												if(shopping.deliverOrder(shopping.getStore().checkOrder(Integer.parseInt(orderId)))) {
													System.out.println("Order Delivered Succesfully");
												}
												else {
													//Lost in shipping
													System.out.println("Order lost in shipping.");
												}
											}
											else {
												//Shipping Error
												System.out.println("Error: Not shipped.");
											}
										}
										else {
											System.out.println("Payment is not sufficient");
										}
										break;
									case 2:
										//Cancel Payment
										shopping.cancelPayment(shopping.getStore().checkOrder(Integer.parseInt(orderId)));
										break;

									default:
										System.out.println("Wrong operation.");
										break;
									}
								}
								else {
									System.out.println("Order information is wrong.");
								}
								
								
								
								break;
							case 3:
								//Cancel Order
								System.out.println("Give an order id to cancel order");
								String orderIdToCancel = operation.nextLine();
								if(isInteger(orderIdToCancel, 10) && shopping.getStore().checkOrder(Integer.parseInt(orderIdToCancel))!= null) {
									shopping.cancelOrder(shopping.getStore().checkOrder(Integer.parseInt(orderIdToCancel)));
								}
								else {
									System.out.println("Order id information is wrong.");
								}
								break;

							default:
								System.out.println("Wrong input.");
								break;
							}
						}
						else {
							System.out.println("Please provide correct input");
						}
					}
					else {
						System.out.println("Customer information not found.");
						break;
					}
					
					break;
				case 2:
					//Register
					System.out.println("Name:");
					String name = operation.nextLine();
					System.out.println("Address:");
					String address = operation.nextLine();
					System.out.println("Savings:");
					String savings = operation.nextLine();
					System.out.println("Phone number:");
					String phoneNumber = operation.nextLine();
					System.out.println("Email:");
					String registerEmail = operation.nextLine();
					System.out.println("Password:");
					String registerPassword = operation.nextLine();
					if(isInteger(savings, 10)) {
						shopping.getStore().addCustomer(name, address, Integer.parseInt(savings), phoneNumber, registerEmail, registerPassword);	
						break;
					}
					else {
						System.out.println("Savings must be integer");
						break;
					}
					
				case 3:
					//Exit
					exit();
					break;
				default:
					System.out.println("Incorrect Input");
					break;	
			}
		}

		return true;
		
	}
}