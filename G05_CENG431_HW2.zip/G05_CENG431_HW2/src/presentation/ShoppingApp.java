//G05

package presentation;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;

public class ShoppingApp {

	public static void main(String[] args) throws ParseException, FileNotFoundException, IOException, org.json.simple.parser.ParseException {
		
		ShoppingMenu menu = new ShoppingMenu();
		while(menu.start()) {}
	}
}