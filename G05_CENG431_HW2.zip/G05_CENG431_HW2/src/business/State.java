//G05

package business;

public enum State {
	INITIAL {
        @Override
        State doSomething(String aParameter) {
            return SAVED;
        }
    },
	SAVED {
        @Override
        State doSomething(String aParameter) {
        	if(aParameter.equals("Delete"))
        		return CANCELLED;
        	else if (aParameter.equals("Placed"))
        		return PLACED;
        	else
        		return this;
        }
    },
    PLACED {
        @Override
        State doSomething(String aParameter) {
        	if(aParameter.equals("Cancel"))
        		return CANCELLED;
        	else if (aParameter.equals("Charged"))
        		return CHARGED;
        	else
        		return this;
        }
    },
    CHARGED {
        @Override
        State doSomething(String aParameter) {
        	if(aParameter.equals("Cancel"))
        		return CANCELLED;
        	else if(aParameter.equals("notEnough"))
        		return PLACED;
        	else if(aParameter.equals("Shipped"))
        		return SHIPPED;
        	else
        		return this;
        }
    },
    SHIPPED {
        @Override
        State doSomething(String aParameter) {
        	if(aParameter.equals("Deliver"))
        		return DELIVERED;
        	else if(aParameter.equals("notShipped"))
        		return CHARGED;
        	else
        		return this;
        }
    },
    CANCELLED {
        @Override
        State doSomething(String aParameter) {
            return FINAL;
        }
    },
    DELIVERED {
        @Override
        State doSomething(String aParameter) {
        	if(aParameter.equals("Lost"))
        		return CHARGED;
        	else if(aParameter.equals("Delivered"))
        		return FINAL;
        	else
        		return this;
        }
    },
    FINAL {
        @Override
        State doSomething(String aParameter) {
            return this;
        }
    };

 abstract State doSomething(String aParameter);	
 
}