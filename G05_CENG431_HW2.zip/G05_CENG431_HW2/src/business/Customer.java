//G05

package business;

public class Customer {
	
	private int id;
	private String name;
	private String address;
	private double savings;
	private String phone;
	private String email;
	private String password;
	
	public Customer(int id, String name, String address, double savings, String phone, String email, String password) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.savings = savings;
		this.phone = phone;
		this.email = email;
		this.password = password;
	}
	
	public void addSavings(double savings) {
		if(savings > 0) 
			this.savings = this.savings + savings;
		else
			System.out.println("Invalid argument for adding savings.");
	}
	
	public void withdrawSavings(double savings) {
		if(savings > 0 && this.savings > savings) 
			this.savings = this.savings - savings;
		else
			System.out.println("Invalid argument for withdrawing savings.");
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public double getSavings() {
		return savings;
	}

	public String getPhone() {
		return phone;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", address=" + address + ", savings=" + savings + ", phone="
				+ phone + ", email=" + email + ", password=" + password + "]";
	}
	
}