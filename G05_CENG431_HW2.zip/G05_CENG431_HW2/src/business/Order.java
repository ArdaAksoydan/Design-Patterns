//G05

package business;

import java.util.Date;

public class Order {
	
	private int id;
	private int trackingNumber;
	private int customerID;
	private String customerName;
	private double weight;
	private String shippingAddress;
	private Date dateShipped;
	private Date dateDelivered;
	private double productPrice;
	private double cargoPrice;
	private double totalPrice;
	private State state;
	
	public Order(int id, int trackingNumber, int customerID, String customerName, double weight, String shippingAddress,
			Date dateShipped, Date dateDelivered, double productPrice, double cargoPrice, double totalPrice) {
		this.id = id;
		this.trackingNumber = trackingNumber;
		this.customerID = customerID;
		this.customerName = customerName;
		this.weight = weight;
		this.shippingAddress = shippingAddress;
		this.dateShipped = dateShipped;
		this.dateDelivered = dateDelivered;
		this.productPrice = productPrice;
		this.cargoPrice = cargoPrice;
		this.totalPrice = totalPrice;
		this.state = State.INITIAL;
	}
	
	public void performRequest(String aParameter) {
        state = state.doSomething(aParameter);
    }

	public int getId() {
		return id;
	}

	public int getTrackingNumber() {
		return trackingNumber;
	}

	public int getCustomerID() {
		return customerID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public double getWeight() {
		return weight;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public Date getDateShipped() {
		return dateShipped;
	}

	public Date getDateDelivered() {
		return dateDelivered;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public double getCargoPrice() {
		return cargoPrice;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public State getState() {
		return state;
	}
	
	public void setId(int id) {
		if(id >= 0)
			this.id = id;
		else
			System.out.println("Invalid id.");
	}

	public void setTrackingNumber(int trackingNumber) {
		if(trackingNumber >= 100000)
			this.trackingNumber = trackingNumber;
		else
			System.out.println("Invalid tracking number.");
	}

	public void setCustomerID(int customerID) {
		if(customerID >= 0)
			this.customerID = customerID;
		else
			System.out.println("Invalid customer id.");
	}

	public void setCustomerName(String customerName) {
		if(!customerName.equals(null))
			this.customerName = customerName;
		else
			System.out.println("Invalid customer name.");
	}

	public void setWeight(double weight) {
		if(weight > 0)
			this.weight = weight;
		else
			System.out.println("Invalid weight value.");
	}

	public void setShippingAddress(String shippingAddress) {
		if(!shippingAddress.equals(null))
			this.shippingAddress = shippingAddress;
		else
			System.out.println("Invalid shipping address.");
	}

	public void setDateShipped(Date dateShipped) {
		if(!dateShipped.equals(null))
			this.dateShipped = dateShipped;
		else
			System.out.println("Invalid date shipped.");
	}

	public void setDateDelivered(Date dateDelivered) {
		if(!dateDelivered.equals(null))
			this.dateDelivered = dateDelivered;
		else
			System.out.println("Invalid date delivered.");
	}

	public void setProductPrice(double productPrice) {
		if(productPrice > 0)
			this.productPrice = productPrice;
		else
			System.out.println("Invalid product price.");
	}

	public void setCargoPrice(double cargoPrice) {
		if(cargoPrice > 0)
			this.cargoPrice = cargoPrice;
		else
			System.out.println("Invalid cargo price.");
	}

	public void setTotalPrice(double totalPrice) {
		if(totalPrice >0)
			this.totalPrice = totalPrice;
		else
			System.out.println("Invalid total price.");
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", trackingNumber=" + trackingNumber + ", customerID=" + customerID
				+ ", customerName=" + customerName + ", weight=" + weight + ", shippingAddress=" + shippingAddress
				+ ", dateShipped=" + dateShipped + ", dateDelivered=" + dateDelivered + ", productPrice=" + productPrice
				+ ", cargoPrice=" + cargoPrice + ", totalPrice=" + totalPrice + ", state=" + state + "]";
	}
	
}