//G05

package business;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import dataAccess.FileManager;

public class Shopping {
	
	private Store store;
	private FileManager fileManager;
	
	public Shopping() {
		this.store = new Store();
	}
	
	public Order saveOrder(Customer customer, String shippingAdress, double weight) {
		Random random = new Random();
		Order order = new Order(0, 0, 0, null, 0, null, null, null, 0, 0, 0);
		order.performRequest("Saved");
		int id = this.store.getOrderList().size();
		int trackingNumber = random.nextInt(900000) + 100000;
		order.setId(id);
		order.setTrackingNumber(trackingNumber);
		order.setCustomerID(customer.getId());
		order.setCustomerName(customer.getName());
		order.setShippingAddress(shippingAdress);
		order.setWeight(weight);
		
		store.addOrder(order);
		
		return order;
	}
	
	public void submitOrder(Order order) {
		order.performRequest("Placed");
		Random random = new Random();
		int deliveryDistance = random.nextInt(401) + 100;
		double cargoPrice = 0.53 * deliveryDistance;
		double productPrice = order.getWeight() * 55;
		order.setCargoPrice(cargoPrice);
		order.setProductPrice(productPrice);
	}
	
	public boolean chargeCustomer(Customer customer, Order order) {
		order.performRequest("Charged");
		double totalPrice = order.getCargoPrice() + order.getProductPrice();
		order.setTotalPrice(totalPrice);
		if(customer.getSavings() < order.getTotalPrice()) {
			cancelPayment(order);
			return false;
		}
		else {
			return true;
		}
	}
	
	public boolean cancelPayment(Order order) {
		if(order.getState() == State.CHARGED) {
			System.out.println("Order canceled by store in placed charged.");
			order.performRequest("notEnough");
			return true;
		}else {
			System.out.println("Order is in the wrong state for cancel.");
			return false;
		}
	}
	
	public boolean shipOrder(Customer customer, Order order) {
		customer.withdrawSavings(order.getTotalPrice());
		order.performRequest("Shipped");
		Random random = new Random();
		int realShippingDurationInDays = random.nextInt(10) + 1;
		int plannedShippingDurationInDays = random.nextInt(10) + 1;
		if(realShippingDurationInDays - plannedShippingDurationInDays > 7) {
			System.out.println("Error: Not shipped.");
			order.performRequest("notShipped");
			return false;
		}else {
			Date date = new Date();
			Date dateShipped = addDays(date, realShippingDurationInDays);
			order.setDateShipped(dateShipped);
			return true;
		}
	}
	
	public boolean deliverOrder(Order order) {
		order.performRequest("Deliver");
		Random random = new Random();
		int realDeliveryDurationInDays = random.nextInt(10) + 3;
		int plannedDeliveryDurationInDays = random.nextInt(10) + 3;
		if(realDeliveryDurationInDays - plannedDeliveryDurationInDays > 8) {
			System.out.println("Error: Lost in shipping.");
			order.performRequest("Lost");
			return false;
		}else {
			Date dateDelivered = addDays(order.getDateShipped(), realDeliveryDurationInDays);
			order.setDateDelivered(dateDelivered);
			order.performRequest("Delivered");
			//fileManager.writeOrdersFile(this.getStore().getOrderList()); Not working, sadly...
			return true;
		}
	}
	
	public boolean cancelOrder(Order order) {
		if(order.getState() == State.PLACED) {
			System.out.println("Order canceled by customer in placed state.");
			order.performRequest("Cancel");
			endIt(order);
			return true;
		}else if(order.getState() == State.CHARGED) {
			System.out.println("Order canceled by customer in charged state.");
			order.performRequest("Cancel");
			endIt(order);
			return true;
		}else {
			System.out.println("Order is in the wrong state for cancel.");
			return false;
		}
		
	}
	
	public boolean deleteOrder(Order order) {
		if(order.getState() == State.SAVED) {
			System.out.println("Order deleted by customer.");
			order.performRequest("Delete");
			endIt(order);
			return true;
		}else {
			System.out.println("Order is in the wrong state for delete.");
			return false;
		}
	}
	
	private boolean endIt(Order order) {
		if(order.getState() == State.CANCELLED) {
			order.performRequest("endIt");
			return true;
		}else {
			System.out.println("Order is in the wrong state for ending it.");
			return false;
		}
	}
	
	private static Date addDays(Date date, int days)
    {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, days);
        return calendar.getTime();
    }

	public Store getStore() {
		return store;
	}
	
}