//G05

package business;

import java.util.ArrayList;
import java.util.Date;
import dataAccess.FileManager;

public class Store {
	
	private ArrayList<Customer> customerList;
	private ArrayList<Order> orderList;
	private FileManager fileManager;
	
	public Store() {
		this.customerList = new ArrayList<Customer>();
		this.orderList = new ArrayList<Order>();
		this.fileManager = new FileManager();
		
	}
	
	public boolean getCustomersFromFile() {
		ArrayList<ArrayList<String>> customerListFromFile = fileManager.readCustomerFromFile();
		if(customerListFromFile.size() != 0) {
			for(ArrayList<String> customer : customerListFromFile) {
				Customer newCustomer = new Customer(Integer.parseInt(customer.get(0)), customer.get(1), customer.get(2), Double.parseDouble(customer.get(3)), customer.get(4), customer.get(5), customer.get(6));
				this.customerList.add(newCustomer);
			}
			return true;
		}
		else {
			return false;
		}
	}
	public boolean getOrderFromFile() {
		ArrayList<ArrayList<String>> ordersFromFile = fileManager.readOrdersFile();
		if(ordersFromFile.size() != 0) {
			for(ArrayList<String> order : ordersFromFile) {
				Date shippedDate = new Date(order.get(6));
				Date deliverDate = new Date(order.get(7));
				Order newOrder = new Order(Integer.parseInt(order.get(0)), Integer.parseInt(order.get(1)), Integer.parseInt(order.get(2)), order.get(3), 
						Double.parseDouble(order.get(4)), order.get(5), shippedDate, deliverDate,  Double.parseDouble(order.get(8)),  Double.parseDouble(order.get(9)), Double.parseDouble(order.get(10)));
				this.orderList.add(newOrder);
			}
			return true;
		}	
		else {
			return false;
		}
	}
	
	public void writeToFile() {
		fileManager.writeCustomersFile(this.customerList);
		fileManager.writeOrdersFile(this.orderList);
	}
	
	public boolean addCustomer(String name, String address, int savings, String phone, String email, String password) {
		if(name.isEmpty() || savings < 0 || address.isEmpty() || phone.isEmpty() || email.isEmpty() || password.isEmpty()) {
			System.out.println("Customer could not created because of invalid value.");
			return false;
		}
		for(Customer c: customerList) {
			if(c.getName().equals(name) && c.getPhone().equals(phone) && c.getEmail().equals(email)) {
				System.out.println("Customer with given parameters already created.");
				return false;
			}
		}
		int customerID = this.customerList.size();
		Customer customer = new Customer(customerID, name, address, savings, phone, email, password);
		customerList.add(customer);
		
		return true;
		
	}
	
	public boolean addOrder(Order order) {
		if(order.getCustomerName().equals(null) || order.getCustomerID() < 0 || order.getId() <0) {
			System.out.println("Order could not created because of invalid value.");
			return false;
		}
		for(Order o: orderList) {
			if(o.getId() == order.getId()) {
				System.out.println("Order with given ID already created.");
				return false;
			}
		}
		orderList.add(order);
		return true;
	}
	
	public Customer checkCustomer(String email, String password) {
		for(Customer customer: customerList) {
			if(customer.getEmail().equals(email) && customer.getPassword().equals(password)) {
				return customer;
			}
		}
		return null;
	}
	public Order checkOrder(int orderId) {
		for(Order order: orderList) {
			if(order.getId() == orderId) {
				return order;
			}
		}
		return null;
	}

	public ArrayList<Customer> getCustomerList() {
		return customerList;
	}

	public ArrayList<Order> getOrderList() {
		return orderList;
	}

	@Override
	public String toString() {
		return "Store [customerList=" + customerList + ", orderList=" + orderList + "]";
	}
	
}